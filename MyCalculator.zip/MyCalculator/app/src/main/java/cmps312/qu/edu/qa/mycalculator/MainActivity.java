package cmps312.qu.edu.qa.mycalculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
private Button b1,b2,b3,b4,b5,b6,b7,b8,b9,b0,bAdd,bSub,bMulti,bDiv,bDot;
private TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b0 = (Button) findViewById(R.id.button_0);
        b1 = (Button) findViewById(R.id.button_1);
        b2 = (Button) findViewById(R.id.button_2);
        b3 = (Button) findViewById(R.id.button_3);
        b4 = (Button) findViewById(R.id.button_4);
        b5 = (Button) findViewById(R.id.button_5);
        b6 = (Button) findViewById(R.id.button_6);
        b7 = (Button) findViewById(R.id.button_7);
        b8 = (Button) findViewById(R.id.button_8);
        b9 = (Button) findViewById(R.id.button_9);
        bDot = (Button) findViewById(R.id.button_dot);
        textView = (TextView) findViewById(R.id.textView);
    }

    protected void pressButtonNumber(View v){
        switch (v.getId()){
            case R.id.button_0: textView.setText("0");
            break;
            case R.id.button_1: textView.setText("1");
                break;
            case R.id.button_2: textView.setText("2");
                break;
            case R.id.button_3: textView.setText("3");
                break;
            case R.id.button_4: textView.setText("4");
                break;
            case R.id.button_5: textView.setText("5");
                break;
            case R.id.button_6: textView.setText("6");
                break;
            case R.id.button_7: textView.setText("7");
                break;
            case R.id.button_8: textView.setText("8");
                break;
            case R.id.button_9: textView.setText("9");
                break;
            case R.id.button_dot: textView.setText(".");

        }
    }

}
